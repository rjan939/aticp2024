#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

struct Student {
  string first_name;
  string last_name;
  int percentage_grade;  
  char letter_grade;
};

vector<string> split(string line) {
  vector<string> tokens;
  string token;
  char delimiter = ' ';
  size_t start = 0;
  size_t index = line.find(delimiter, start);

  while (index != string::npos) {
    size_t length = index - start;
    tokens.push_back(line.substr(start, length));
    start += length + 1;
    index = line.find(delimiter, start);
  }
  tokens.push_back(line.substr(start));
  return tokens;
}

char calculateGrade(int grade) {
  if (grade >= 90) return 'A';
  if (grade >= 80) return 'B';
  if (grade >= 70) return 'C';
  if (grade >= 60) return 'D';
  return 'F';
}

vector<Student> getData(ifstream &infile) {
  vector<Student> students;
  string line;
  int x = 0;
  while (getline(infile, line)) {
    vector<string> tokens = split(line);
 
    if (tokens.size() == 3) {
      int grade = stoi(tokens[2]);
      Student student = { tokens[0], tokens[1], grade, calculateGrade(grade) };
      students.push_back(student);
    }
    x++;
  } 
  return students;
}

int highestScore(const vector<Student>& students) {
  int highest = 0;
  for (const auto& student : students) { 
    highest = max(highest, student.percentage_grade);
  }
  return highest;
}

void writeData(ofstream &outfile, const vector<Student>& students) {
  for (const auto& student : students) {
    outfile << student.first_name << " " << student.last_name << " "
            << student.percentage_grade<< " " << student.letter_grade << '\n';
  } 
}

int main(int argc, const char *argv[]) {
  if (argc < 3) {
    cerr << "Usage: " << argv[0] << " <input_file>" << " <output_file>" << '\n';
    return 1;
  }

  string input_file_name = argv[1];
  string output_file_name = argv[2];

  ifstream infile(input_file_name);
  if (!infile) {
    cerr << "Error: Could not open input file " << input_file_name << '\n';
    return 1;
  }

  vector<Student> students = getData(infile);
  infile.close();
  cout << highestScore(students) << '\n';
  ofstream outfile(output_file_name);
  if (!outfile) {
    cerr << "Error: Could not open output file " << output_file_name << '\n';
    return 1;
  }
  writeData(outfile, students);
  outfile.close();
  
  return 0;
}
