#include <iostream>

using namespace std;

int main(int argc, const char *argv[]) {
    cout << "Hello, World" << "\n";
    return 0;
}